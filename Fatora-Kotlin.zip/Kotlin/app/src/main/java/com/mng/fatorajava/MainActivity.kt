package com.mng.fatorajava

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val pay = findViewById<Button>(R.id.pay)
        pay.setOnClickListener { view: View? -> generatePaymentButton() }
    }

    private fun generatePaymentButton() {
        val thread = Thread(Runnable {
            try {
                generatePayment()
            } catch (exception: Exception) {
                Log.e("Exception", exception.toString())
            }
        })
        thread.start()
    }

    @Throws(Exception::class)
    private fun generatePayment() {
        // URL of the endpoint we're going to contact (MAKTAPP CLOUD SOLUTIONS credit endpoint.
        val url = URL("https://maktapp.credit/v3/AddTransaction")

        // Create a POST request with our JSON as a request body.
        val con = url.openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.setRequestProperty("Content-Type", "application/json; utf-8")
        con.setRequestProperty("Accept", "application/json")
        con.doOutput = true

        // Create a simple dictionary with numbers.
        val dataIn = JSONObject(dataInPut as Map<*, *>).toString()
        con.outputStream.use { os ->
            val input = dataIn.toByteArray(charset("utf-8"))
            os.write(input, 0, input.size)
        }
        BufferedReader(
                InputStreamReader(con.inputStream, "utf-8")).use { br ->
            val response = StringBuilder()
            var responseLine: String? = null
            while (br.readLine().also { responseLine = it } != null) {
                response.append(responseLine!!.trim { it <= ' ' })
            }

            //if code is 200 so the request return success so the response came back with data object that contain result value this have payment url link
            if (con.responseCode == 200) {
                val result = JSONObject(response.toString())
                val urlPayement = result["result"] as String
                val intent = Intent(this@MainActivity, WebActivity::class.java)
                intent.putExtra("URL", urlPayement)
                startActivity(intent)
            }
        }
    }

    val dataInPut: HashMap<String, String>
        get() {
            val dataIn = HashMap<String, String>()
            dataIn["token"] = "E4B73FEE-F492-4607-A38D-852B0EBC91C9" //put here your account token
            dataIn["currencyCode"] = "QAR" //put here your currency code
            dataIn["orderId"] = "100" //put here your order id
            dataIn["Note"] = "" //put here your notes
            dataIn["customerName"] = "demo" //put here your customer name
            dataIn["customeremail"] = "demo@fatora.io" //put here your customer email
            dataIn["customerPhone"] = "" //put here your customer phone
            dataIn["isrecurring"] = "" //if your payment is recurring so you need to put (1) else (0)
            dataIn["customerCountry"] = "Qatar" //put here your customer country
            dataIn["Lang"] = "en" //put here your language (en or ar)
            dataIn["Amount"] = "50" // put here your amount
            dataIn["from"] = "0" // put here from attributes value
            return dataIn
        }
}